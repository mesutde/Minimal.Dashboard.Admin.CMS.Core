﻿using Microsoft.AspNetCore.Mvc;

namespace WebApplication2.Controllers
{
    public class ArticleController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}